# Devotion - DoD Bordello Patch

Install this archive as a new MO2 mod named `Devotion - Bordello Patch`.

Read `Docs\PDV_Phase21_DoD_PackageInstall.md` before enabling it. The package replaces Wintersun gameplay with Devotion and requires regenerated Synthesis, ParallaxGen, TexGen if required, and DynDOLOD outputs after Wintersun is removed.

This package does not include `PDV_DoD_Compatibility.esp`; current readback proves the shrine replacement slice through `Devotion.esp`. Ohmes-Raht / Half-Khajiit origin support is shipped as a data-only `PDV_RaceMap.json` entry mapping the normal and vampire HalfKhajiit races to Khajiit origin index `6`. Future DoD extensibility candidates are documented in `Docs\PDV_Phase21_DoD_AuthoriaReuseAudit.md`.