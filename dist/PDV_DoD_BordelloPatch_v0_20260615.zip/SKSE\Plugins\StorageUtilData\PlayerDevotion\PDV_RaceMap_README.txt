PlayerDevotion - Custom Race Map (PDV_RaceMap.json)
===================================================

WHAT THIS IS
------------
PlayerDevotion assigns devotion theology by your character's race. Vanilla races
are recognized automatically. Most custom/modded races are ALSO recognized
automatically when they ship with one of the common compatibility frameworks:

  - RaceCompatibility (TMPhoenix): the race carries an "ActorProxy<Vanilla>"
    keyword (e.g. ActorProxyNord). PlayerDevotion reads it and maps the race to
    that vanilla profile. No action needed.
  - Race Blood Test (yzx_dnatest.dll): spoofs your race to its vanilla
    equivalent at the engine level. If your race already reads as a vanilla race
    in-game, PlayerDevotion already maps it correctly. No action needed.

You only need THIS file for a custom race that neither framework tags - for
example a UBE/COR/DZ race used without RaceCompatibility, or any exotic race the
heuristics miss. The file lets you (or a patch author) map such races by hand,
with no script edits and no recompiling.

HOW TO EDIT
-----------
This is a PapyrusUtil JSON file. Add one entry to BOTH lists, in the same order:

  "raceForms"   - the race record, written as "0x<FormID>|<PluginName>"
  "raceIndices" - the vanilla profile to treat it as, by index:
                    0 Nord    1 Imperial   2 Breton   3 Altmer    4 Bosmer
                    5 Dunmer  6 Khajiit    7 Argonian 8 Orsimer   9 Redguard

The FormID is the race's load-order FormID (find it in xEdit / SSEEdit). UBE
race EditorIDs are self-describing - e.g. 00UBE_NordRace -> index 0,
00UBE_DarkElfRace -> index 5, 00UBE_HighElfRace -> index 3.

EXAMPLE (map two UBE races; replace FormIDs/plugin with yours from xEdit):

  {
    "raceForms":   ["0x000800|UBE.esp", "0x000801|UBE.esp"],
    "raceIndices": [0, 5]
  }

The override map takes precedence over the automatic framework detection, so an
entry here always wins. Entries whose plugin is not installed are ignored
safely. Keep the two lists the same length.
